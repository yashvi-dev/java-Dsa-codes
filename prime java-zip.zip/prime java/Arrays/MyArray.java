package Arrays;

public class MyArray {

    // CREATING OWN ARRAY FROM SCRATCH

    // array if items 
    private int[] items;
    
    // to kep track of current index in an array
    private int curretntIndex;

// ****************************************************************************************************************
    // This is a Constructor
    // initialize items with initialSize
    // currentIndex to 0 
    public MyArray(int initialSize){
        this.items =new int[initialSize];
        this.curretntIndex = 0;
    }

    // this is a method 
    public void insert(int value){

        // value into the items array at the position indicated by curretntIndex and then increments curretntIndex.
        this.items[curretntIndex]=value;
        curretntIndex++;
    }

// ********************************************************************************************************
    public int indexOf(int value){
    // LINEAR SEARCH-> we will travesre whle array if we found elemnt we will return the index else we will return negative 1 i.e -1

    // WAY 1----------------------------
        for(int i=0 ;i< this.items.length; i++){
            if(this.items[i]== value){
                return i;
            }
        }
        return -1;

        // this.items.currentIndex

    // if you have size as 15 but you have inserted only 5 lements so serch in 5 elemnts na hwy to waste the time 
}
// **************************************************************************************************************
 public void removeAt(int index){
    for(int i=index; i<this.curretntIndex-2;i++){
        this.items[i]=this.items[i+1];
        // this.items[curretntIndex-1]= 0;
        curretntIndex--;
    }
    
   
 }
// *****************************************************************************************************************
    //    crates a string representaion of items 
    // concating each element followed by comma 
    public String toString(){

        // MORE FEASIBLE WAY----------------------
        StringBuilder str = new StringBuilder();
        str.append("[");
        for(int num: this.items){
            str.append(num+ " ");
        }
        str.append("]");
        return str.toString();


        // WAY-2 OF DOING IT --------------------------
        // String str = new String();
        // for (int num: this.items){
        //     str=str+(num+ ",");
        // }
        // return str;
    }

// **********************************************************************************************

public int max(){

    int max= this.items[0];
    for(int i=1 ; i<this.curretntIndex;i++){
        if(items[i]>max){
            max=items[i];
        }
    }

    return max;
}
// ********************************************************************************************************
   public int min(){
        int min= this.items[0];
        for(int i=1 ; i<this.curretntIndex;i++){
            if(items[i]<min){
                min=items[i];
            }

   }
  return min ;
    }

    // **************************************************************************************************

    public void reverse(){
        int i=0;
        int j= this.curretntIndex-1;
        while (i<j){
            int temp = this.items[i];
            this.items[i]=this.items[j];
            this.items[j]=temp;
            i++;
            j--;

        }
    }
}

