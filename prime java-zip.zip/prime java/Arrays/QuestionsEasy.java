package Arrays;

import java.util.*;

public class QuestionsEasy {
  
        public static int[] buildArray(int[] nums) {
            if(nums.length== 0){
                return new int[]{0,0};
            }

            int n= nums.length;
            // size fo the array 
            int[] res = new int[n]; 

            for(int i=0;i<n;i++){
                res[i]=nums[nums[i]];
            }
           
            return res;
        }

        public static int[] getConcatenation(int[] nums) {
            if(nums.length== 0){
                return new int[]{0,0};
            }

            int n= nums.length;
            int[] res= new int[n*2];  

            for(int i=0; i<n; i++){
                res[i] = nums[i];
                res[i+n] = nums[i];
            }
            return res;
        }

       
        public static void main(String[] args) {
        //     int[] arr= {0,2,1,5,3,4};
        //    int ans1= Occurance(arr, 5, 0);
           
        // int ans =optimisePow(2, 5);
        //   System.out.println(ans);

        int ans= tilingP(5);
        System.out.println(ans);

        }

        public static int Occurance(int[] arr, int key , int i){
            if(i==arr.length-1){
                return -1;
            }

            if(arr[i]==key){
                return i;
            }

            return Occurance(arr, key, i+1);
        }
    
        public static int power(int x, int n){
            if( n==1){
                return x;
        }
        int xno= power(x, n-1);
        int xn= x* xno;
        return xn;
    }

        public static int optimisePow(int a, int n){
            if(n==0){
                return 1;

            }

            int halfpow= optimisePow(a, n/2);
            int halfpowsq= halfpow*halfpow;

            if(n%2 !=0){
                return a*halfpowsq;
            }

            return halfpowsq;
        }

        public static int tilingP(int n){
            if(n == 0 || n == 1){
                System.out.println("Base case n=" + n + ", result=1");
                return 1;
            }
        
            System.out.println("Computing tilingP(" + n + ")");
            int fnmo = tilingP(n - 1);
            int fnm1 = tilingP(n - 2);
            int totalways = fnmo + fnm1;
        
            System.out.println("For n=" + n + ", ways=" + totalways);
            return totalways;
        }
        
}


