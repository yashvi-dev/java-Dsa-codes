package Arrays;
import java.util.Scanner;


public class basic {
    Scanner in = new Scanner(System.in);

    public double areaCircle(int r){
        return 3.14*r*r;

    }

    public double areaTriangle(double b, double h){
        return 0.5*b*h;

    }

    public double areaRectangle(double l, double b){
        return l*b;

    }

    public double areaIsocelesTraingle(double b, double h){
        return 0.5*b*h;

    }

    public double areaParallelogram(double h, double b){
        return h*b;

    }

    public double areaRhombus(double d1, double d2){
        return 0.5*d1*d2;

    }

    public double areaEquilatralTraingle(double s){
        return 0.333*s;

    }

    public double perimeterofCircle(double r){
        return 2*3.14*r;
    }

    private static long[] fibonacciCache;

    public static long fibonacciSeries(int n){
        if(n<=1){
            return n;
        }

        if(fibonacciCache[n]!=0){}

        // fibonacciCache =new long[n+1];
        long result =fibonacciSeries(n-1)+fibonacciSeries(n-2);

        fibonacciCache[n]=result;

        return (result);
        
    }


    // Java Program for Sum the digits of a given number
    public static int sumOfDigits(int n) {
        int sum = 0;
        while(n!=0){
            sum = sum + n/10;
            n = n%10;
        }
        return sum;
    }
    
    public static void main(String[] args) {
        System.out.println(sumOfDigits(123));
    }
}
