package Arrays;

import java.lang.reflect.Array;
import java.util.Arrays;

public class basic2doperation {
    public static int[][] addition(int[][] arr1, int[][] arr2){
        int sum[][] =new int[2][2];
        for(int i=0;i<2;i++){
            for(int j=0;j<2;j++){
                sum[i][j]=arr1[i][j]*arr2[i][j];
            }
        }
        return sum ;
    }
    public static void main(String[] args) {
        int[][] arr1 = {
            {1,2},
            {3,4},
        };
        int[][] arr2 = {
            {1,1},
            {1,1},
        };
        System.out.println(Arrays.deepToString(addition(arr1, arr2)));
    }
}
