package Arrays;


public class main {
    public static void main(String[] args) {
     
        MyArray arr = new MyArray(2);

       
        arr.insert(1);
        arr.insert(2);
        // arr.insert(8);
        // arr.insert(4);
        // arr.insert(10);

        // arr.removeAt(0);
        // arr.insert();
        arr.reverse();
        System.out.println(arr);


        }
}
