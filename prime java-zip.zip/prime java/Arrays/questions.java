package Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;
import java.util.Arrays;


public class questions {
      
    // Subtaract product from sum
    public static int sumOfDigits(int n) {
        int sum = 0;
        while(n!=0){
            sum = sum + n%10;
            n = n/10;
        }
        return sum;
    }

    public static int productOfDigits(int n){
        int product=1;

        while(n!=0){
            product = product * (n%10);
            n = n/10;
        }
        return product;
    }

    // Input a number and print all the factors of that number (use loops).
    public static int factors(int n){
        for(int i=1 ;i<1;i++){
            if(n%i==0){
                System.out.println(i);
            }
        }
        return n;
    }

    // Take integer inputs till the user enters 0 and print the sum of all numbers
    public static int inputs(){
        Scanner in= new Scanner(System.in);  
         int total=0;
         int num;
        while (true) {
         num= in.nextInt();
        if(num==0){
            break;
        }
        total+= num;
        }
        return -1;
    }

    // Take integer inputs till the user enters 0 and print the largest number from all.
    public static int largestNumber(){
        Scanner in= new Scanner(System.in);
        int num ;
        int max =Integer.MIN_VALUE;

        while(true){
            num = in.nextInt();
            if(num==0){
                break;
        }
        if(num>max){
            max = num;
            System.out.println(num);
    
        }else{
            System.out.println(max);
        }
        

    }
    return -1;
    }

    // Factorial Program In Java
    public static int factorial(int n) {

        int factorial=1;
        if (n == 0 || n == 1){
            return 1;
        }
        if (n>=2) {
            for(int i=1; i<=n;i++){
                factorial = factorial * i;
            }

            // System.out.println(factorial);
            
        }
        return factorial;
      
    }

    // DISTANCE BETWEEN TWO POINTS -   
    public static double distance(double x1, double y1, double x2, double y2){
        double distance = Math.sqrt((Math.pow((x2 - x1), 2) )+(Math.pow((y2 - y1), 2)));
        return distance;
    }

    // Sum Of N Numbers
    public static int sumOfN(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum+=i;
        }
        return sum;

    }
    // Armstrong Number In Java
    public static boolean isArmstrong(int n) {
        int original = n;
        int cubesum = 0;
        int numDigits = (int) Math.log10(n) + 1; // Calculate the number of digits
    
        while (n != 0) {
            cubesum += Math.pow(n % 10, numDigits);
            n /= 10; // Use integer division here
        }
    
       if (cubesum == original) {
            return true;
       }else{
        return false;
       }
    }
    
    
       
    // }
    // Find Ncr & Npr
    public static int Ncr(int n, int r) {
        if (n==0 || r==0){
            return 0;
        }

        int numerator =factorial(n);
        int denominator = factorial(n-r)*factorial(r);
        int result = numerator/denominator;

        return result;
        
    }

    // Reverse A String In Java
    public static String reverse(String str){
        String result = "";

        for(int i= str.length();i>=0;i--){
            result = result + str.charAt(i);
        }
        return result;

    }
  
        public static  int[] buildArray(int[] nums) {
            if(nums.length == 0){
                return new int[0];
            }

            int ans[] =new int[nums.length];
            for(int i=0;i<nums.length;i++){
                int index = nums[i];
                ans[i]= nums[index];

            }
            return ans;
        }


            public static  int[] getConcatenation(int[] nums) {
                
                int n =(nums.length);
                int ans[]= new int[n*2];
               for(int i=0;i<nums.length;i++){
                ans[i] =nums[i];
                ans[i+n]=nums[i];

               }
               return ans;
            }

            public static int[] runningSum(int[] nums) {
                int ans[]= new int[nums.length];
                for(int i=1;i<nums.length;i++){
                    ans[0]=nums[0];
                    ans[i]= ans[i-1]+nums[i];
                }


                return ans;
            }
        
            public int maximumWealth(int[][] accounts) {
               int maxWealth=0;
          
                for(int i=0;i<accounts.length;i++){
                   int currentWealth=0;
                    for(int j=0; j<accounts[i].length;j++){
                       currentWealth += accounts[i][j];
                    }
                    if(currentWealth>maxWealth){
                        return maxWealth= currentWealth;
                    }
               
            }
            return maxWealth;
        }

         public static List<Boolean> kidsWithCandies(int[] candies, int extraCandies) {
             List<Boolean> result =new ArrayList<>();
             int max = candies[0];

             for(int i=0 ;i<candies.length;i++){
                max = Math.max(max,candies[i]);
                
             }
             for (int candyCount : candies) {
                result.add(candyCount + extraCandies >= max);
            }
             return result;

        }
    
   
        public int numIdenticalPairs(int[] nums) {
            int  res =0;
            int[] countaArray= new int[101];
            for(int i :  nums){
                countaArray[i]++;
                }

            for(int count: countaArray){
                count = (count* (count-1))/2;
                res+=count;
            }
            return res; 
        }
    // 1365
        public int[] smallerNumbersThanCurrent(int[] nums) {
        int[] ans =new int[nums.length];
        for(int i=0; i<nums.length;i++){

        }
        return ans;
    }

    // 162
    public static int findPeakElement(int[] nums) {
        for (int i = 0; i < nums.length; i++) {
            if (i > 0 && i < nums.length - 1) {
                if (nums[i] > nums[i - 1] && nums[i] > nums[i + 1]) {
                    return i;
                }
            } else if (i == 0 && nums.length > 1) {
                if (nums[i] > nums[i + 1]) {
                    return i;
                }
            } else if (i == nums.length - 1 && nums.length > 1) {
                if (nums[i] > nums[i - 1]) {
                    return i;
                }
            } else if (nums.length == 1) {
                return i;
            }
        }
        return -1;
    }

    // 1389
    public static 
    int[] createTargetArray(int[] nums, int[] index) {
     List<Integer> targetList =new ArrayList<>();

     for(int i=0 ;i<nums.length;i++){
        targetList.add(index[i], nums[i]);

     }
     int[] targetArray = new int[targetList.size()];
     for (int i=0;i<targetList.size();i++){
        targetArray[i]=targetList.get(i);
     }
     return targetArray;
       

      

    }

    public static
    int[] arrayreturn(int[] nums){
        int[] sol = new int[nums.length];
        for(int i=0;i<nums.length;i++){
            sol[i]= i;

        }
        return sol; 
    }


    

    public static void main(String[] args) {
     int[] nums = {5,10,20,15};
     System.out.println(Arrays.toString(arrayreturn(nums)));
   
      
    }

}
