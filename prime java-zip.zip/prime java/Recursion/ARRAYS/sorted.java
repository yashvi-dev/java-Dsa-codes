package Recursion.ARRAYS;
import java.util.Arrays;

public class sorted  {
    public static void main(String[] args) {
        int[] arr={1,2,8,9,5};
    //    System.out.println(sortedd(arr, 0));
    //    System.out.println(linearSearch(arr, 9, 0));
    //    System.out.println(linearSearch2(arr, 5, 0));
    //     arr= mergesort(arr);
    //     System.out.println(Arrays.toString(arr));



    }
    static boolean sortedd(int[] arr, int idx){
        // base condotion
        if(idx==arr.length-1){
            return true;
    }
    return arr[idx]<arr[idx+1] && sortedd(arr, idx+1);
}

    static boolean linearSearch(int[] arr, int target, int idx)
    {
        // base condition
        if (idx== arr.length) {
            return false;
        }
        
        return arr[idx]==target || linearSearch(arr, target, idx+1);
    }

    static int linearSearch2(int[] arr, int target ,int idx){
        if (idx== arr.length) {
            return 0;
        }

        if (arr[idx]== target) {
            return idx;
        }else{
            return linearSearch2(arr, target, idx+1);
        }
    }
// -------------------------------------------------------------------------------------------------

    static int[] mergesort(int[] arr ){
        // base condition 
        if(arr.length==1){
            return arr;
        }

        // devide array into halves
        int mid=arr.length/2;

        // range of the left side of array and right side of the array
        int[] left= mergesort(Arrays.copyOfRange(arr, 0, mid));
        int[] right= mergesort(Arrays.copyOfRange(arr, mid, arr.length));

        return merge(left, right);
    }
    private static int[] merge(int[] first, int[] second) {
        
        // size of new array the sorted one 
        int[] mix = new int[first.length+second.length];

        // i= arr1 ptr
        // j= arr2 ptr
        // k= new sorted array ptr
        int i=0;
        int j=0;
        int k=0;

        while (i<first.length && j<second.length) {
            if (first[i]<second[j]) {
                mix[k]=first[i];
                // move i by 1
                i++;
            }else{
                mix[k]=second[j];
                // move j by 1
                j++;
            }
            // whenevr u add element u have to move ahead so-> k is ptr to mix arr
            k++;
        }

        // it may be possible that one of the array is not complete like all the elemnets are not covered-> i is gonna be smaller than length or j is gonna be smaller than length
        // so we have to add the remaining elements in the mix array

        // in both of these loops either one of them is going to run 
        while (i<first.length) {
            mix[k]=first[i];
            i++;
            k++;
        }
        while (j<second.length) {
            mix[k]=second[j];
            j++;
            k++;

    }
    return mix;
}
// ------------------------------------------------------------------------------------------
    static void mergesortInplace(int[] arr, int start, int end){
        if (arr.length==1) {
            return ;
        }

        int mid= start +(end-start)/2;
        mergesortInplace(arr, start, mid);
        mergesortInplace(arr, mid+1, end);

        mergeInplace(arr, start, mid, end);
    }
    private static void mergeInplace(int[] arr, int start, int mid, int end) {

        int[] mix= new int[end- start];

        int i=start;//first halv wiil start from beigining ->mid
        int  j= mid;//second half will start form mid->end
        int k=0;

        while (i<mid &&j<end) {
            if (arr[i]<arr[j]) {
                mix[k]= arr[i];
                i++;

            }else{
                mix[k]=arr[j];
                j++;
            }
            k++;
        }
// there may be extra elements in the array 
        while (i<mid) {
            mix[k]=arr[i];
            i++;
            k++;
        }
        while (j<end) {
            mix[k]=arr[j];
            j++;
            k++;
        }

        // modifying the orignal array 
        for (int l = 0; l < mix.length; l++) {
            arr[start+l]=mix[l];
        }
        
    }

    static void quickSort(int[] nums, int low, int high){
        if(low>=high){
            return; 
        }
        int start= low;
        int end= high;
        int mid= start + (end-start)/2;
        int pivot=nums[mid];

        while (start<=end) {
            while (nums[start]<pivot) {
                start++;
            }
            while (nums[end]>pivot) {
                end--;
            }

            if (start<=end) {
                int temp= nums[start];
                nums[start]=nums[end];
                nums[end]=temp;
                start++;
                end--;
            }
        }

        quickSort(nums, low, end);
        quickSort(nums, start, high);
    }
}
