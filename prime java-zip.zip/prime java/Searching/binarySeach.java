package Searching;
import java.util.Arrays;
public class binarySeach {

        // int mid= start +(end- start)/2
    
        public static int binarySearch(int[] arr, int target) {
            int start = 0;
            int end = arr.length - 1;
    
            while (start <= end) {
                int mid = start + (end - start) / 2;
    
                if (target == arr[mid]) {
                    return mid; 
                } else if (target < arr[mid]) {
                    end = mid - 1; 
                } else {
                    start = mid + 1; 
                }
            }
    
            return -1; 
        }
        
        // you dont know it is ascending or decending 
        public static int agonisticBsearch(int[] arr, int target){
            int start=0;
            int end= arr.length -1;
            boolean isAgonistic= arr[start]<arr[end];

            while(start<=end){
                int mid=start+(end-start)/2;

                if (target== arr[mid]){
                    return mid; 
                }

                if (isAgonistic) {
                    if (target< arr[mid]) {
                        end = mid - 1;
                    }else{
                        start = mid + 1;
                    }
                }else{
                    if (target>arr[mid]) {
                        end = mid - 1;
                    }else{
                        start = mid + 1;
                    }
                }
           }
           return -1;
        }
    // ------------QUESTIONS-------------
        // CELING ELEMENT 
        static int celinglElement(int[] arr , int target){

          int start =0;
          int end = arr.length-1;

          while (start<=end) {
            int mid = start+ (end-start)/2;
            if (target > arr[mid]) {
                return start = mid+1;
            }else if(target<arr[mid]){
               return end = mid - 1;
            }else{
               return mid;
            }
          }
           return arr[start];
        }

        //QUESTION2 
        public char nextGreatestLetter(char[] letters, char target) {   

            int start= 0;
            int end = letters.length - 1;

            while (start<=end) {
                int mid= start + (end-start)/2;
                if(target < letters[mid]){
                    end = mid - 1;
                }else{
                    start =mid+1;
                }
            }
            return letters[start%letters.length]; 

        }

// QUESTION3

    public static int peakElement(int[] arr){
        int start =0;
        int end = arr.length-1;

        while (start< end) {
            int mid= start +(end-start)/2;

            if(arr[mid]<arr[mid+1]){
                start = mid+1;
            }else if(arr[mid]>arr[mid+1]){
                end= mid;

            }
        }
        return start;
        
    }
 
    public static int searchInIsagonistic(int[] arr ,int target){
        int start =0;
        int end = peakElement(arr);

        boolean isAgonistic = arr[start]<arr[end];
        
      while(start<=end) {
        
        int mid= start +(end- start)/2;
            if(target == arr[mid]){
                return mid;
             }

             if(isAgonistic){
                if(target < arr[mid]){
                    end= mid-1;

                }else{
                    start = mid+1;
                }
             }else{
                if(target > arr[mid]){
                    end= mid-1;
                    
                }else{
                    start= mid+1;
                }
             }
            
       }
       
       return -1;
    }

 
    

        public static void main(String[] args) {
            // int[] arr = {2, 4, 6, 9, 11, 12, 14, 20, 36, 48};
            int[] arr= {2,3,5,9,14,16,18};
            int target = 15;
          int sol= celinglElement(arr, target);
           System.out.println(sol);
        }

       
}