package Searching;

import java.lang.reflect.Array;
import java.util.Arrays;

public class linear1 {

    public static int linear( int target){
        int[] arr ={1,2,3,4,5,6};
       if(arr.length == 0){
        return -1;
       }

        for(int i=0;i<= arr.length; i++ ){
            int element = arr[i];
            if (element == target) {
                return i;
            }
        }
        return -1;
    }
// Search a char in a String -----
    public static boolean linearQ1(String str , char target){
        if(str.length()== 0){
            return false;
        }

        for(int i=0 ;i<str.length();i++){
            char element = str.charAt(i);
            if(element == target){
                return true;
            }
        }
        return false;
    }
//search in a range ---------------------
    public static int linearRange(int target){
        int[] arr= {18,12,-7,3,14,28};
        if(arr.length== 0){
            return -1;
        }

        for(int i= 1; i<= arr[4];i++){
            int element =arr[i];
            if(element == target){
                return i;
            }
        }
        return -1;
    }
// search the min in arrray 
    public static int linearMin(){

        int[] arr= {18,12,-7,3,14,28};
        int ans =0;
        for(int i=0;i<arr.length;i++){
            if(arr[i]<ans){
                return ans= arr[i];
            }
        }
    return ans;
    }
// searcing in 2d array
  static int[] twoDSearch(int target){
        int[][] arr ={
            {23,4,1},
            {18,12,3,9},
            {14,7,5,6} 
        };

        for(int row=0;row<arr.length;row++){
            for(int col=0; col<arr[row].length;col++){
                if(arr[row][col] == target){
                    
                    return new int[]{row,col};
            }
        }
    }
    return new int[]{-1,-1};
 }
// int array mai count
public static int findNumbers(int[] nums) {
    int count=0;
    for(int num : nums){
        if(evenDigits(num)){
            count++;
        }
    }
    return count;
}
// Even number of digits 
public static boolean evenDigits(int num) {
    if (countEvenDigits(num)%10==0) {
        return  true;

    }else{
        return false;
    }
}

// counting even digits in a number 
public static int countEvenDigits(int num) {
    int count =0;
    while (count!=0) {
        count++;
        num= num/10;
    }
    return count;
}
    public static void main(String[] args) {
        
        int[] num ={12, 345 , 2 , 6 , 7896};
        System.out.println(findNumbers(num)); 
       

        
    }
}
