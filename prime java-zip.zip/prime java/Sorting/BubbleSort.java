package Sorting;
import java.util.Arrays;
public class BubbleSort {

    static void code(int[] arr){
        boolean swapped;
        for (int i = 0; i < arr.length; i++) {
            swapped= false;
            for (int j = 1; j < arr.length-i; j++) {
                // swap fi the item is smaller than the previous item
                if(arr[j]<arr[j-1]){
                    // if swapping is occuring 
                    int temp =arr[j];
                    arr[j]=arr[j-1];
                    arr[j-1]=temp;
                    swapped= true;
                }
            }
            if(!swapped){ //!false =true
                break;
            }
        }
    }

    public static void main(String[] args) {
        // run the steps n-1 times 
        int[] arr={2,3,7,1,9};
        code(arr);
        System.out.println(Arrays.toString(arr));

     

    }
}
