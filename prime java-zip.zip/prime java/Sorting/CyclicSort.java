package Sorting;
import java.util.Arrays;
public class CyclicSort {

    static void cyclicsort(int[] arr){
       int i=0;
       while(i<arr.length){
        int correct =arr[i]-1;
        if (arr[i] != arr[correct]) {
            swap(arr, i, correct);
        }else{
            i++;
        }
       }
    }

    static void swap(int[] arr, int start, int end){
        int temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;

    }
// -----------------------------------------------------------------
// QUESTIONS
// -----------------------------------------------------------------
    public static int missingNumber(int[] nums) {
            int i=0;
            while(i<nums.length){
                int correct =nums[i]-1;
                if (nums[i] != nums[correct]) {
                    swap(nums, i, correct);
                }else{
                    i++;
                }
            }

            if(nums[i] != i){
                return i;
            }
        return i;
    }













        public static void main(String[] args) {
        int[] nums ={3,0,1};
        missingNumber(nums);
        System.out.println(Arrays.toString(nums));
    }
}
