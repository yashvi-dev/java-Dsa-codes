package oops.Lab1;

 class Item {



    //memeber vairable
    private String ItemName;
    private String ItemidNo;
    private int ItemQuantity;
    private double ItemPrice;

    //constructor 
   /*The constructor initializes the object when it is created.
It takes four parameters: name, id, quantity, and price. */
    Item(String Name,String idNo,int Quantity,double Price){
        this.ItemName=Name;
        this.ItemidNo=idNo;
        this.ItemQuantity=Quantity;
        this.ItemPrice=Price;
    }

    Item(String Name,String idNo,int Quantity){
        this.ItemName=Name;
        this.ItemidNo=idNo;
        this.ItemQuantity=Quantity;
        this.ItemPrice= 500;
    }

    Item(String Name,String idNo){
        this.ItemName=Name;
        this.ItemidNo=idNo;
        this.ItemQuantity=1;
        this.ItemPrice= 500;
    }

    

    // Mutators 
    public void set_ItemName(String Name){
        ItemName = Name;
    }

    public void set_ItemidNo(String idNo){
        ItemidNo = idNo;
    }

    public void set_ItemQuantity(int Quantity){
        ItemQuantity = Quantity;
    }
    public void set_ItemPrice(double Price){
        ItemPrice = Price;
    }

    //accesor methods

    public String get_ItemName(){
        return ItemName;
    }

    public String get_ItemidNo(){
        return ItemidNo;
    }

    public int get_ItemQuantity(){
        return ItemQuantity;
    }
    public double get_ItemPrice(){
        return ItemPrice;
    }
}

/**
 * Customer
 */
class Customer {
 public String Name;
 public String idNo;
 public double balance;
// private  Item item;
    
}