package oops.Lab1;

import java.util.Scanner;

public class index {
    public static void main(String[] args) {

        int num1;
        double double1;
        String numStr1, numStr2;

        Scanner in = new Scanner(System.in);
        num1 = in.nextInt();
        System.out.println("you have entered : " + num1);

        double1 = in.nextDouble();
        System.out.println("you have entered : " + double1);

        numStr1 = in.next();
        System.out.println("you have entered : " + numStr1);

        numStr2 = in.nextLine();
        System.out.println("you have entered : " + numStr2);

        in.close();
    }
}
